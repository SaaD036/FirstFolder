package er_design;

import java.util.logging.*;
import java.sql.*;
import java.util.*;

public class ER_Design { 
   
    public static void main(String[] args) {
        String URL = "jdbc:oracle:thin:@localhost:1521:XE";
        Scanner input;
        
        try {
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
            }
            catch (ClassNotFoundException ex) {
                Logger.getLogger(ER_Design.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            System.out.println("Driver loaded successfully");
            Connection con = DriverManager.getConnection(URL, "saad", "111111");
            System.out.println("Connection established");
           
            
            int option=1;
            input = new Scanner(System.in);
            
            while(option != 0){
                System.out.println("Choose 1 for insert, 2 for show, 0 for exit");
                option = input.nextInt();
                
                if(option == 1){
                    int yn=1;
                    
                    while(yn != 0){
                        int pro_num, ticket_total;
                        String designation;
                        System.out.print("/nEnter problem number : ");
                        pro_num = input.nextInt();
                        System.out.print("Enter total ticket number : ");
                        ticket_total = input.nextInt();
                        String a = input.nextLine();
                        System.out.print("Enter designation: ");
                        designation = input.nextLine();


                        Statement statement = con.createStatement();
                        int update = statement.executeUpdate("insert into PROBLEM values (" + pro_num + ", "+ticket_total+", '"+ designation +"')");
                    
                        System.out.println("1 for next input, 0 for quit");
                        yn = input.nextInt();
                        
                        System.out.println("");
                    }
                    
                    System.out.println("");
                    System.out.println("");
                }
                else if(option == 2){
                    Statement statement = con.createStatement();
                    ResultSet allData = statement.executeQuery("select * from PROBLEM");
                    
                    while(allData.next()){
                        System.out.println(allData.getInt("PNUMBER"));
                        System.out.println(allData.getInt("TICKET_TOTAL_NUMBER"));
                        System.out.println(allData.getString("DESIGNATION"));
                        
                        System.out.println("");
                    }
                    
                    System.out.println("");
                    System.out.println("");
                }
            }
        }
        catch (SQLException ex) {
            Logger.getLogger(ER_Design.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
